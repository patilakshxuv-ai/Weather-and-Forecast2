WEATHER & FORECAST — SAMPLE DEVELOPER WEBSITE

Deploy this folder as a static site on Vercel.

IMPORTANT BEFORE PUBLISHING
1. Confirm the AdMob publisher ID in public/app-ads.txt matches the AdMob account used by the app.
2. Replace [Developer / legal name], [support email], [Add publication date], and all privacy-policy placeholders with accurate information.
3. Ensure the privacy policy matches the actual app, permissions, location use, weather API, advertising SDKs, analytics, and data retention.
4. Remove or edit any feature claims that are not implemented in the app.
5. In Google Play Console, use https://weather-and-forecast.vercel.app/ as the developer website only if you control this domain and it is the correct site for this app.
6. After deployment, test https://YOUR-DOMAIN/app-ads.txt and confirm it displays the exact publisher line as plain text.

DEPLOY
- Upload/import this folder into a GitHub repository and connect it to Vercel, or deploy the folder using Vercel's supported workflow.
- The app-ads.txt file is in public/app-ads.txt so typical static-site deployments publish it at /app-ads.txt.
